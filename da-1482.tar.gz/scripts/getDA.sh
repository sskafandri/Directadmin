#!/bin/sh

FILE=/usr/local/directadmin/update.tar.gz
wget -O $FILE "https://raw.githubusercontent.com/irf1404/Directadmin/master/update.tar.gz"
